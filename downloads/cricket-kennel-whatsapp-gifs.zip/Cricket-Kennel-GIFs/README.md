# Cricket Kennel — animated shorts

Six four-second character animations, with matching GIF and silent MP4 files.
The dogs move through individually drawn cricket and tea poses. The camera is fixed.

Licence: CC BY-NC 4.0 — https://creativecommons.org/licenses/by-nc/4.0/
Project and creator attribution: https://maadhavkothari.github.io/cricket-kennel/#licence

For WhatsApp, save a short MP4 to your phone and attach it from Photos/Gallery. If the editor offers a GIF switch, select it. Check the preview before sending.
The ZIP does not install a pack or add GIFs to WhatsApp search. No phone send test is claimed.

These shorts are separate from the downloadable desktop pet packages.
