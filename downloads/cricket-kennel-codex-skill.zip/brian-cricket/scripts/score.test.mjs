import test from 'node:test';
import assert from 'node:assert/strict';
import { newBook, record, summarize, addInnings, scoreHtml } from './score.mjs';
const delivery = (overrides={}) => ({type:'delivery',note:'Verified test work',evidence:'Local test evidence',...overrides});
const current = b => summarize(b.innings.find(i=>i.id===b.active_innings));

test('six legal deliveries make an over; wides/no-balls add extras but not legal deliveries',()=>{
  let b=newBook();for(let i=0;i<6;i++)b=record(b,delivery());
  b=record(b,delivery({extras:{wide:1}}));b=record(b,delivery({extras:{no_ball:1}}));
  assert.equal(current(b).overs,'1.0');assert.equal(current(b).total,2);assert.equal(current(b).task_runs,0);
});
test('LBW/caught are forbidden on no-balls, and LBW is forbidden on wides',()=>{
  for(const dismissal of ['lbw','caught'])assert.throws(()=>record(newBook(),delivery({dismissal,extras:{no_ball:1}})),/no-ball/);
  assert.throws(()=>record(newBook(),delivery({dismissal:'lbw',extras:{wide:1}})),/wide/);
  assert.equal(current(record(newBook(),delivery({dismissal:'run_out',extras:{no_ball:1}}))).wickets,1);
});
test('a legal LBW records the fall of wicket and consumes a delivery',()=>{
  const s=current(record(newBook(),delivery({dismissal:'lbw'})));
  assert.equal(s.wickets,1);assert.equal(s.dismissals.lbw,1);assert.equal(s.overs,'0.1');
});
test('pausing never scores or consumes a delivery and blocks play until resumed',()=>{
  let b=record(newBook(),{type:'pause',note:'Awaiting user input'});
  assert.equal(current(b).total,0);assert.equal(current(b).legal_balls,0);
  assert.throws(()=>record(b,delivery()),/Resume/);
  b=record(b,{type:'resume',note:'User answered'});assert.equal(current(record(b,delivery())).legal_balls,1);
});
test('work cannot earn runs twice, including across formats',()=>{
  let b=record(newBook(),delivery({bat_runs:4,boundary:'four',task_id:'same'}));b=addInnings(b,'t20');
  assert.throws(()=>record(b,delivery({bat_runs:4,task_id:'same'})),/already earned/);
});
test('milestones use verified work runs, never extras',()=>{
  let b=newBook();for(let i=0;i<8;i++)b=record(b,delivery({bat_runs:6,task_id:String(i),boundary:'six'}));
  b=record(b,delivery({extras:{wide:3}}));assert.equal(current(b).milestones.length,0);
  b=record(b,delivery({bat_runs:2,task_id:'fifty'}));assert.equal(current(b).milestones[0].runs,50);
});
test('T20 closes at 120 legal balls; Test remains uncapped',()=>{
  let t=newBook('t20'),u=newBook('test');for(let i=0;i<120;i++){t=record(t,delivery());u=record(u,delivery());}
  assert.equal(current(t).closed,true);assert.throws(()=>record(t,delivery()),/closed/);
  assert.equal(current(record(u,delivery())).legal_balls,121);
});
test('10 wickets close the innings; timed-out does not consume a ball',()=>{
  let b=newBook();b=record(b,{type:'dismissal',dismissal:'timed_out',note:'Failed abandoned attempt',evidence:'Evidence'});
  assert.equal(current(b).legal_balls,0);for(let i=0;i<9;i++)b=record(b,delivery({dismissal:'bowled'}));
  assert.equal(current(b).closed,true);assert.throws(()=>record(b,delivery()),/closed/);
});
test('void corrections retain history and remove score credit',()=>{
  let b=record(newBook(),delivery({id:'original',bat_runs:6,task_id:'one'}));
  b=record(b,{type:'void',target:'original',reason:'Wrong credit',note:'Score correction'});
  assert.equal(b.innings[0].events.length,2);assert.equal(current(b).total,0);
  b=record(b,delivery({bat_runs:1,task_id:'one'}));assert.equal(current(b).total,1);
});
test('rejects contradictory extras, invalid boundaries and missing evidence; export escapes text',()=>{
  assert.throws(()=>record(newBook(),delivery({extras:{wide:1,no_ball:1}})),/overrides/);
  assert.throws(()=>record(newBook(),delivery({bat_runs:1,boundary:'six',task_id:'bad'})),/disagree/);
  assert.throws(()=>record(newBook(),{type:'delivery',note:'No evidence'}),/evidence/);
  const b=record(newBook(),delivery({note:'<script>bad</script>'}));
  assert.match(scoreHtml(b),/&lt;script&gt;bad&lt;\/script&gt;/);assert.doesNotMatch(scoreHtml(b),/<script>bad/);
});
