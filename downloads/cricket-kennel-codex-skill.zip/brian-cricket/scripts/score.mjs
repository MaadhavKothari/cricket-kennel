import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const FORMATS = { test: null, odi: 300, t20: 120 };
export const DISMISSALS = ['bowled', 'caught', 'lbw', 'run_out', 'stumped', 'hit_wicket', 'hit_ball_twice', 'obstructing_field', 'timed_out', 'retired_out'];
export const MILESTONES = [
  [50, 'Half-century'], [100, 'Century'], [150, '150 up'], [200, 'Double century'],
  [250, '250 up'], [300, 'Triple century'], [375, 'Lara tribute: 375, Test cricket, 1994'],
  [400, 'Lara tribute: 400*, Test cricket, 2004'], [500, 'Five hundred'],
  [501, 'Lara tribute: 501*, first-class cricket, 1994'],
];
const EXTRA_KEYS = ['wide', 'no_ball', 'byes', 'leg_byes', 'penalty'];
const noBallDismissals = ['run_out', 'obstructing_field', 'hit_ball_twice'];
const wideDismissals = ['run_out', 'stumped', 'hit_wicket', 'obstructing_field'];
const requireThat = (condition, message) => { if (!condition) throw new Error(message); };
const nonnegative = n => Number.isSafeInteger(n) && n >= 0;
export const overs = balls => `${Math.floor(balls / 6)}.${balls % 6}`;

export function newBook(format = 'test') {
  requireThat(format in FORMATS, 'Format must be test, odi, or t20.');
  const inning = { id: randomUUID(), format, opened_at: new Date().toISOString(), events: [] };
  return { version: 1, pet: 'Brian Labra', innings: [inning], active_innings: inning.id };
}

export function activeEvents(inning) {
  const voided = new Set(inning.events.filter(e => e.type === 'void').map(e => e.target));
  return inning.events.filter(e => e.type !== 'void' && !voided.has(e.id));
}

export function summarize(inning) {
  const s = { format: inning.format, total: 0, task_runs: 0, wickets: 0, legal_balls: 0, deliveries: 0,
    completed_tasks: 0, fours: 0, sixes: 0, extras: Object.fromEntries(EXTRA_KEYS.map(k => [k, 0])),
    dismissals: Object.fromEntries(DISMISSALS.map(k => [k, 0])), fall_of_wickets: [], paused: false, declared: false };
  for (const e of activeEvents(inning)) {
    if (e.type === 'pause') { s.paused = true; continue; }
    if (e.type === 'resume') { s.paused = false; continue; }
    if (e.type === 'declare') { s.declared = true; continue; }
    if (e.type === 'delivery') {
      s.deliveries++;
      if (!e.extras.wide && !e.extras.no_ball) s.legal_balls++;
      s.task_runs += e.bat_runs;
      s.total += e.bat_runs;
      if (e.bat_runs > 0) s.completed_tasks++;
      for (const k of EXTRA_KEYS) { s.extras[k] += e.extras[k]; s.total += e.extras[k]; }
      if (e.boundary === 'four') s.fours++;
      if (e.boundary === 'six') s.sixes++;
    }
    if (e.dismissal) {
      s.wickets++; s.dismissals[e.dismissal]++;
      s.fall_of_wickets.push({ wicket: s.wickets, score: s.total, overs: overs(s.legal_balls), dismissal: e.dismissal, note: e.note });
    }
  }
  s.overs = overs(s.legal_balls);
  s.closed = s.declared || s.wickets >= 10 || (FORMATS[s.format] !== null && s.legal_balls >= FORMATS[s.format]);
  s.milestones = MILESTONES.filter(([n]) => s.task_runs >= n).map(([runs, label]) => ({ runs, label }));
  s.next_milestone = MILESTONES.find(([n]) => n > s.task_runs) ?? null;
  return s;
}

export function record(book, input) {
  requireThat(book.version === 1 && Array.isArray(book.innings), 'Unsupported scorebook.');
  const copy = structuredClone(book);
  const inning = copy.innings.find(i => i.id === copy.active_innings);
  requireThat(inning, 'Active innings is missing.');
  const e = { ...input, id: input.id || randomUUID(), at: new Date().toISOString() };
  requireThat(!copy.innings.some(i => i.events.some(x => x.id === e.id)), 'Duplicate event id.');
  requireThat(typeof e.note === 'string' && e.note.trim(), 'Every event needs a concise note.');
  const prior = summarize(inning);
  if (e.type === 'void') {
    requireThat(typeof e.reason === 'string' && e.reason.trim(), 'A correction needs a reason.');
    requireThat(activeEvents(inning).some(x => x.id === e.target), 'Correction target is missing or already voided.');
    // Corrections retain the original event and reason in the journal.
    inning.events.push(e);
    const after = summarize(inning);
    requireThat(after.wickets <= 10 && (FORMATS[after.format] === null || after.legal_balls <= FORMATS[after.format]), 'Correction would create an invalid innings.');
    return copy;
  }
  if (['pause', 'resume', 'declare'].includes(e.type)) {
    requireThat(!prior.closed, 'Innings is closed; start a new innings.');
    if (e.type === 'declare') requireThat(inning.format === 'test', 'Declarations apply only to this scorekeeper’s Test mode.');
    inning.events.push(e); return copy;
  }
  requireThat(!prior.closed, 'Innings is closed; start a new innings.');
  requireThat(!prior.paused, 'Resume the innings before recording play.');
  requireThat(typeof e.evidence === 'string' && e.evidence.trim(), 'A delivery or dismissal requires evidence.');
  requireThat(['delivery', 'dismissal'].includes(e.type), 'Unknown event type.');
  if (e.dismissal) requireThat(DISMISSALS.includes(e.dismissal), 'Unknown dismissal.');
  if (e.type === 'dismissal') {
    requireThat(['timed_out', 'retired_out'].includes(e.dismissal), 'Non-delivery dismissals are timed_out or retired_out.');
    requireThat(!e.bat_runs && !e.extras && !e.boundary, 'Non-delivery dismissals cannot carry runs or extras.');
  } else {
    e.bat_runs ??= 0;
    requireThat(nonnegative(e.bat_runs) && e.bat_runs <= 6, 'Task runs must be an integer from 0 to 6.');
    const supplied = e.extras ?? {};
    requireThat(Object.keys(supplied).every(k => EXTRA_KEYS.includes(k)), 'Unknown extra type.');
    e.extras = Object.fromEntries(EXTRA_KEYS.map(k => [k, supplied[k] ?? 0]));
    requireThat(Object.values(e.extras).every(nonnegative), 'Extras must be non-negative integers.');
    requireThat(e.extras.no_ball <= 1, 'Use one no-ball penalty; place other runs in the appropriate field.');
    requireThat(!(e.extras.no_ball && e.extras.wide), 'A no-ball overrides a wide; do not score both.');
    requireThat(!(e.extras.byes && e.extras.leg_byes), 'Byes and leg-byes are mutually exclusive.');
    requireThat(!(e.bat_runs && (e.extras.wide || e.extras.byes || e.extras.leg_byes)), 'Bat runs cannot also be wides, byes, or leg-byes.');
    requireThat(!(e.extras.wide && (e.extras.byes || e.extras.leg_byes)), 'Wide runs cannot also be byes or leg-byes.');
    requireThat(!['timed_out', 'retired_out'].includes(e.dismissal), 'Use a non-delivery dismissal event.');
    if (e.extras.no_ball && e.dismissal) requireThat(noBallDismissals.includes(e.dismissal), 'That dismissal is not valid from a no-ball.');
    if (e.extras.wide && e.dismissal) requireThat(wideDismissals.includes(e.dismissal), 'That dismissal is not valid from a wide.');
    if (e.dismissal && !['run_out', 'obstructing_field'].includes(e.dismissal)) requireThat(e.bat_runs === 0, 'This dismissal cannot credit completed bat runs.');
    if (e.boundary) requireThat((e.boundary === 'four' && e.bat_runs === 4) || (e.boundary === 'six' && e.bat_runs === 6), 'Boundary and bat runs disagree.');
    if (e.bat_runs) {
      requireThat(typeof e.task_id === 'string' && e.task_id.trim(), 'Credited work requires a stable task_id.');
      requireThat(!copy.innings.some(i => activeEvents(i).some(x => x.task_id === e.task_id && x.bat_runs > 0)), 'This task has already earned runs.');
    }
  }
  inning.events.push(e);
  return copy;
}

export function addInnings(book, format) {
  requireThat(format in FORMATS, 'Format must be test, odi, or t20.');
  const copy = structuredClone(book);
  const inning = newBook(format).innings[0];
  copy.innings.push(inning); copy.active_innings = inning.id;
  return copy;
}

export function scoreText(book) {
  const inning = book.innings.find(i => i.id === book.active_innings);
  const s = summarize(inning);
  const extras = Object.values(s.extras).reduce((a,b) => a+b, 0);
  const dismissals = Object.entries(s.dismissals).filter(([,v]) => v).map(([k,v]) => `${k.toUpperCase().replaceAll('_',' ')} ${v}`).join(' · ') || 'None';
  return [`BRIAN LABRA’S XI · ${s.format.toUpperCase()}`,
    `${s.total}/${s.wickets} (${s.overs} overs) · ${s.fours} ${s.fours===1?'four':'fours'} · ${s.sixes} ${s.sixes===1?'six':'sixes'}`,
    `Verified work: ${s.task_runs} runs from ${s.completed_tasks} completed items. Extras: ${extras}.`,
    `Dismissals: ${dismissals}`,
    s.closed ? 'Innings closed.' : s.paused ? 'Tea interval / awaiting play. No delivery counted.' : 'At the crease.',
    s.next_milestone ? `Next: ${s.next_milestone[1]} — ${s.next_milestone[0] - s.task_runs} verified-work runs to go.` : 'Beyond 501. Keep building the innings.'].join('\n');
}

const escape = s => String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export function scoreHtml(book) {
  const inning = book.innings.find(i => i.id === book.active_innings);
  const s = summarize(inning);
  const rows = [...activeEvents(inning)].reverse().slice(0,30).map(e => `<tr><td>${escape(e.note)}</td><td>${e.type === 'delivery' ? e.bat_runs + ' runs' : escape(e.type)}</td><td>${escape(e.dismissal || '—')}</td><td>${escape(e.evidence || '—')}</td></tr>`).join('');
  return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Brian Labra · Scorecard</title><style>body{margin:0;background:#f3eedf;color:#2c3027;font:16px system-ui}main{max-width:1000px;margin:60px auto;padding:0 24px}.eyebrow{letter-spacing:.18em;text-transform:uppercase;color:#6f1938}h1{font:clamp(44px,8vw,76px) Georgia;margin:12px 0}.score{background:#183e32;color:#fff9e9;border:6px solid #b59148;border-radius:12px;padding:32px;margin:32px 0}.big{font-size:clamp(70px,15vw,126px);font-weight:700;line-height:1}.meta{font-size:20px;margin-top:18px}pre{font:15px/1.8 system-ui;white-space:pre-wrap}table{width:100%;border-collapse:collapse;font-size:14px}td,th{text-align:left;padding:14px 8px;border-bottom:1px solid #d5cfbe;overflow-wrap:anywhere}th{color:#6f1938}.note{color:#6d7267;font-size:13px;line-height:1.6}a{color:#6f1938}</style><main><div class="eyebrow">The Prince of Paws · ${s.format.toUpperCase()}</div><h1>Brian Labra’s XI</h1><p>Ital on the table. Reggae in the rhythm. Cricket at heart.</p><section class="score"><div class="big">${s.total}/${s.wickets}</div><div class="meta">${s.overs} overs &nbsp; · &nbsp; ${s.fours} ${s.fours===1?'four':'fours'} &nbsp; · &nbsp; ${s.sixes} ${s.sixes===1?'six':'sixes'}</div></section><pre>${escape(scoreText(book))}</pre><h2>This innings</h2><table><thead><tr><th>Work / event</th><th>Score</th><th>Dismissal</th><th>Evidence</th></tr></thead><tbody>${rows || '<tr><td colspan="4">New innings. No completed work has been credited yet.</td></tr>'}</tbody></table><p class="note">A local work scorebook, updated by the Brian Cricket skill. It does not monitor other chats. Extras do not count toward work milestones. Historical landmarks are tributes, not claims of sporting records. Snapshot exported ${escape(new Date().toISOString())}. Reload after the scorekeeper updates this file.</p><p><a href="https://www.wisden.com/wisden-cricketers-almanack/brian-lara-501-375-tribute">Wisden Almanack: Lara’s 375 and 501*</a> · <a href="https://www.wisden.com/cricket-features/brian-laras-top-ten-moments-in-his-own-words">Lara’s milestones</a> · <a href="https://www.lords.org/mcc/the-laws">MCC Laws</a></p></main></html>`;
}

async function main() {
  const [command = 'show', ...args] = process.argv.slice(2);
  const options = {};
  for (let i=0; i<args.length; i+=2) {
    requireThat(args[i]?.startsWith('--') && args[i+1] && !args[i+1].startsWith('--'), 'Options require --name value pairs.');
    requireThat(['file','format','event'].includes(args[i].slice(2)), 'Unknown option.');
    options[args[i].slice(2)] = args[i+1];
  }
  const file = path.resolve(options.file || path.join(os.homedir(), '.codex', 'brian-cricket', 'scorebook.json'));
  if (command === 'show') { console.log(scoreText(JSON.parse(await fs.readFile(file,'utf8')))); return; }
  requireThat(['init','record','new-innings','export'].includes(command), 'Use init, record, show, new-innings, or export.');
  await fs.mkdir(path.dirname(file), { recursive: true });
  let lock;
  const lockFile = file + '.lock';
  try {
    lock = await fs.open(lockFile, 'wx');
    let book;
    if (command === 'init') {
      try { await fs.access(file); throw new Error('Scorebook already exists; init never overwrites it.'); }
      catch (e) { if (e.code !== 'ENOENT') throw e; }
      book = newBook(options.format || 'test');
    } else book = JSON.parse(await fs.readFile(file, 'utf8'));
    if (command === 'record') { requireThat(options.event, 'record requires --event path-to-json.'); book = record(book, JSON.parse(await fs.readFile(options.event,'utf8'))); }
    if (command === 'new-innings') book = addInnings(book, options.format || 'test');
    if (command !== 'export') {
      const tmp = file + '.' + randomUUID() + '.tmp';
      await fs.writeFile(tmp, JSON.stringify(book,null,2)+'\n', { flag: 'wx', mode: 0o600 });
      await fs.rename(tmp, file);
    }
    const htmlFile = path.join(path.dirname(file),'scorecard.html');
    const htmlTmp = htmlFile + '.' + randomUUID() + '.tmp';
    await fs.writeFile(htmlTmp, scoreHtml(book), { flag: 'wx', mode: 0o600 });
    await fs.rename(htmlTmp,htmlFile);
    console.log(scoreText(book));
    console.log(`Scorebook: ${file}\nScorecard: ${htmlFile}`);
  } finally {
    if (lock) { await lock.close(); await fs.unlink(lockFile); }
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === await fs.realpath(process.argv[1]).catch(() => null)) main().catch(e => { console.error(e.message); process.exitCode=1; });
