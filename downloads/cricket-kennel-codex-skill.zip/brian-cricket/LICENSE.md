# Cricket Kennel task skill — CC BY-NC 4.0

The original task instructions, work-metaphor reference material and bundled scorekeeper source in this package are offered under the **Creative Commons Attribution–NonCommercial 4.0 International licence**, to the extent copyright and similar rights apply and the creator can license them.

- Licence: https://creativecommons.org/licenses/by-nc/4.0/
- Full terms: https://creativecommons.org/licenses/by-nc/4.0/legalcode.en
- Creator: Maadhav Kothari
- Project and attribution: https://maadhavkothari.github.io/cricket-kennel/#licence

You may share and adapt the licensed material for noncommercial purposes, with appropriate attribution, a licence link and an indication of changes. See the full terms above.

Linked third-party sources, the official cricket Laws, brands and publicity rights are not licensed by this notice. These are original fictional dog personas and original task metaphors. No athlete, cricket body or OpenAI endorsement is implied. No music or pet artwork is included in this skill package.
