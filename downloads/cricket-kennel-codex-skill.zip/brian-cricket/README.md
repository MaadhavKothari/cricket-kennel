# Cricket Kennel task playbook for Codex

An optional Codex skill that turns cricket calls into concrete work: bowl an over of up to six useful items, catch defects in a review, or use any of the 42 numbered Law recipes. Its local scorekeeper records verified outcomes across invocations. It uses Node.js and no third-party packages.

## Install

1. Unzip `cricket-kennel-codex-skill.zip`. Keep the `brian-cricket` folder and its contents together.
2. Copy that folder into your personal Codex skills directory: `$CODEX_HOME/skills`, or `~/.codex/skills` if `CODEX_HOME` is unset. If `brian-cricket` already exists there, preserve a backup and review the replacement before installing it.
3. Use `$brian-cricket` in your next Codex turn. If it does not appear, reopen Codex. Tell Codex to read the installed `SKILL.md` if needed.

Try these with your own project or artifact:

```text
$brian-cricket bowl an over on the next actionable items in this project.
$brian-cricket Law 33: review this change for actionable defects.
$brian-cricket scorecard
```

Installing the pet artwork is separate. This skill routes Codex requests; it does not control pet frames, add native animation states, play music, monitor other conversations, or install a ChatGPT task integration. The score covers work handled through this skill. A user-input wait is an interval, never a dismissal.

## Local scorekeeper

Use a current Node.js installation. From the installed `brian-cricket` folder:

```sh
node scripts/score.mjs show
```

If no scorebook exists yet, initialize an empty innings:

```sh
node scripts/score.mjs init --format test
```

Initialization refuses to overwrite an existing book. The default journal is `~/.codex/brian-cricket/scorebook.json`; the neighboring `scorecard.html` is refreshed after changes. These paths use your home folder even when `CODEX_HOME` points elsewhere. To select a different local book, append `--file /absolute/path/to/scorebook.json` to each command.

Read [scorekeeping](references/scorekeeping.md) for evidence-backed credits, corrections, Test/ODI/T20 innings and milestones. Do not publish your scorebook, scorecard, event evidence or usage data. The download contains no existing score or personal history.

Optional verification from this folder runs the bundled in-memory checks without touching a scorebook:

```sh
node --test scripts/score.test.mjs
```

## Package contents

The ZIP contains exactly these files under `brian-cricket/`:

```text
SKILL.md
README.md
LICENSE.md
agents/openai.yaml
references/repertoire.md
references/laws.md
references/scorekeeping.md
references/roster.json
scripts/score.mjs
scripts/score.test.mjs
```

The roster is generated from public character profiles and contains only persona fields. [The 42-law map](references/laws.md) supplies original work metaphors and official source links; it is not a cricket rules engine. Verify the applicable official Laws and competition conditions for an actual cricket ruling.

By Maadhav Kothari · [Cricket Kennel](https://maadhavkothari.github.io/cricket-kennel/) · [Licence](LICENSE.md)
