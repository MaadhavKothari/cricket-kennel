# Brian Labra's scorebook

The scorekeeper is `../scripts/score.mjs` relative to this reference folder. It uses Node's standard library and stores an auditable JSON event journal. Default storage is `~/.codex/brian-cricket/scorebook.json`, with a neighboring `scorecard.html` export. It reads and writes only the selected local scorebook and export; there is no external service or hidden chat monitor.

Run `node <skill-dir>/scripts/score.mjs show` to inspect the current innings. If no scorebook exists, run `init --format test`. Use `new-innings --format odi` or `new-innings --format t20` when the user requests a new innings in that format. Previous innings remain in the journal. Test is uncapped, ODI allows 300 valid deliveries, and T20 allows 120. These are normal unreduced innings defaults, not a simulator for rain-adjusted playing conditions, DLS, or Super Overs.

## Earned runs

Use the smallest complete deliverable that is meaningful to the user. Do not separately score its internal steps and then score the same outcome again.

| Runs | Completed outcome |
| ---: | --- |
| 1 | One small verified fix or requested edit. |
| 2 | A small finished artifact with a read-back check. |
| 3 | A completed source-backed analysis or research bundle. |
| 4 | A complete feature, playbook, or kit variant with appropriate validation. |
| 6 | A substantial verified deliverable, such as a fully validated new pet or finished application. |

Write a temporary event JSON file, then call `record --event /absolute/path/to/event.json`. Each credit needs a stable `task_id`, a concise note, and actual evidence. The same task cannot score twice, including in another format. Four and six points can be recorded as boundaries. Example:

```json
{
  "type": "delivery",
  "task_id": "cricket-kennel:brian-test:installed-v2",
  "bat_runs": 6,
  "boundary": "six",
  "note": "Brian Labra Test pet validated and installed",
  "evidence": "/absolute/path/to/qa/run-summary.json"
}
```

This is an example only; do not record it unless the referenced work is really complete. Do not equate a planned animation with a verified animation.

## Dismissals and intervals

Record a wicket only when a bounded attempt has actually failed or been abandoned, with the evidence and reason. A repairable issue in ongoing work is not automatically a wicket. Choose a transparent work metaphor:

- `bowled`: direct underlying failure ended the attempt.
- `caught`: review exposed a disqualifying defect in the attempted result.
- `lbw`: an unmet required condition decisively ended the attempt.
- `run_out`: coordination or a race ended the attempt.
- `stumped`: the attempt proceeded without a prerequisite and failed.
- `hit_wicket`: the change broke its own dependencies or behavior.
- `hit_ball_twice`: a duplicate-effect failure.
- `obstructing_field`: a conflicting operation invalidated the attempt.
- `timed_out`: an actual ended timeout, recorded as a non-delivery dismissal.
- `retired_out`: an explicitly abandoned attempt, recorded as a non-delivery dismissal.

Normal wicket events use `type: delivery`, `bat_runs: 0`, and a `dismissal`. Timed-out and retired-out events use `type: dismissal` and do not consume a ball. The scorekeeper closes an innings at ten wickets.

For an explicit pause or a genuine pending user answer, record `{"type":"pause","note":"Awaiting user input"}` once; resume with a `resume` event when work can continue. Neither event changes runs, wickets or overs. Do not repeatedly log the same waiting state.

## Cricket bookkeeping

Extras are optional cricket game points, recorded only when the user asks to use them. They are never a reward for tool failures and never count as completed work or toward milestones. Supported fields are `wide`, `no_ball`, `byes`, `leg_byes`, and `penalty`. Wides and no-balls do not consume valid balls. The scorer rejects LBW or caught on a no-ball, LBW on a wide, contradictory extras, and mismatched boundary values. This is a bounded work scorekeeper with core cricket checks, not an implementation of every clause of cricket regulation.

The displayed score is the fictional team **Brian Labra's XI**, so multiple wickets are team dismissals, not repeated dismissals of one batter in an innings. Work milestones use `task_runs`, excluding all extras. Overs use cricket notation: `2.4` means two overs and four valid balls, not 2.4 decimal overs.

## Milestones and original celebrations

50: half-century / bat salute. 100: century / small reggae two-step. 200: double century / full salute. 300: triple century / composed master-batter nod. The 375, 400 and 501 thresholds are Lara tributes. These are chat celebrations and gallery themes; no task-specific native animation trigger is claimed.

Wisden's [Almanack account](https://www.wisden.com/wisden-cricketers-almanack/brian-lara-501-375-tribute) documents Lara's 375 in Test cricket and 501 not out in first-class cricket in 1994. Its [Lara retrospective](https://www.wisden.com/cricket-features/brian-laras-top-ten-moments-in-his-own-words) also covers his 400 not out in Test cricket in 2004. Keep those formats and dates distinct. See also the [Almanack's history of the century](https://www.wisden.com/cricket-news/the-tale-of-the-century-250-years-and-counting-almanack-2019). Sources checked 17 September 2026. Do not call a work milestone a sporting record.

## Corrections

To remove an incorrect credit without erasing history, record a `void` event containing the original event's `id` as `target`, plus `reason` and `note`. Then, if needed, record a new corrected event with fresh evidence. The original event remains in the journal.

`export` regenerates the HTML scorecard without changing the journal. `--file /absolute/path/to/scorebook.json` selects a separate project scorebook. Locking prevents overlapping writes; if another writer holds the lock, inspect that writer before retrying instead of deleting its lock.
