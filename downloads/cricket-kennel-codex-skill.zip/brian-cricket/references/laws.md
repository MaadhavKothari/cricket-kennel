# All 42 MCC Law headings linked to Codex tasks

Coverage: every numbered Law has a task recipe below. These are original work metaphors, not a reproduction of every subclause or a playable cricket rules engine. Invoke a row with `$brian-cricket Law 33: review this change` or with its cricket phrase. Supply the target artifact or use the active task.

Sources checked 17 September 2026: [MCC's complete Laws index](https://www.lords.org/mcc/the-laws). MCC says its next edition takes effect on [1 October 2026](https://www.lords.org/lords/news-stories/mcc-announces-new-edition-of-laws-from-1-october-2026). For an actual cricket ruling, verify the relevant edition and competition playing conditions. DRS, powerplays, free hits, and format-specific regulations require their applicable playing conditions; they are not interchangeable with the 42 Laws.

All entries below are implemented as chat-routing instructions in this skill. None is an independent native pet animation trigger.

| Law and official source | Cricket cue | Concrete Codex task |
| --- | --- | --- |
| [1 — The players](https://www.lords.org/mcc/the-laws/the-players) | Pick the XI | Identify required roles, owners, and gaps for the requested project. |
| [2 — The umpires](https://www.lords.org/mcc/the-laws/the-umpires) | Umpire the decision | Review the evidence against the stated criteria and recommend a decision. |
| [3 — The scorers](https://www.lords.org/mcc/the-laws/the-scorers) | Keep score | Produce a source-backed progress and verification record. |
| [4 — The ball](https://www.lords.org/mcc/the-laws/the-ball) | Inspect the ball | Check the input artifact's identity, integrity, and suitability. |
| [5 — The bat](https://www.lords.org/mcc/the-laws/the-bat) | Choose the bat | Select and verify the appropriate available tool for the task. |
| [6 — The pitch](https://www.lords.org/mcc/the-laws/the-pitch) | Read the pitch | Inspect the workspace and runtime before making changes. |
| [7 — The creases](https://www.lords.org/mcc/the-laws/the-creases) | Mark the crease | State the authorized scope and precise completion criteria. |
| [8 — The wickets](https://www.lords.org/mcc/the-laws/the-wickets) | Set the stumps | Identify the essential invariants the work must preserve. |
| [9 — Preparation and maintenance](https://www.lords.org/mcc/the-laws/preparation-and-maintenance-of-the-playing-area) | Prepare the ground | Repair the necessary project setup within the requested scope. |
| [10 — Covering the pitch](https://www.lords.org/mcc/the-laws/covering-the-pitch) | Bring on the covers | Preserve a recoverable state before an authorized risky operation. |
| [11 — Intervals](https://www.lords.org/mcc/the-laws/intervals) | Tea break | On an explicit pause request, save a concise handoff and stop. |
| [12 — Start and cessation of play](https://www.lords.org/mcc/the-laws/start-of-play;-cessation-of-play) | Play / stumps | Start the specified task, or stop it and report its actual state. |
| [13 — Innings](https://www.lords.org/mcc/the-laws/innings) | Plan the innings | Break the requested outcome into ordered, actionable stages. |
| [14 — The follow-on](https://www.lords.org/mcc/the-laws/the-follow-on) | Follow on | Work through the remaining failures after a first validation pass. |
| [15 — Declaration and forfeiture](https://www.lords.org/mcc/the-laws/declaration-and-forfeiture) | Declare | When the user asks to close scope, document what is complete and what is deferred. |
| [16 — The result](https://www.lords.org/mcc/the-laws/the-result) | Match result | Compare the delivered artifact with acceptance criteria and report the result honestly. |
| [17 — The over](https://www.lords.org/mcc/the-laws/the-over) | Bowl an over | Carry out up to six useful work items; count only verified completions. |
| [18 — Scoring runs](https://www.lords.org/mcc/the-laws/scoring-runs) | Add to the score | Record completed items, evidence, and remaining work without inflating totals. |
| [19 — Boundaries](https://www.lords.org/mcc/the-laws/boundaries) | Four / six | Finish a small / substantial authorized deliverable and verify the outcome. |
| [20 — Dead ball](https://www.lords.org/mcc/the-laws/dead-ball) | Dead ball | End an invalid or superseded attempt and preserve the reason in the handoff. |
| [21 — No ball](https://www.lords.org/mcc/the-laws/no-ball) | Check the delivery | Find and correct an input or operation that violates the task's stated constraints. |
| [22 — Wide ball](https://www.lords.org/mcc/the-laws/wide-ball) | Bring it back on line | Identify off-target work and redirect it to the actual request. |
| [23 — Bye and leg bye](https://www.lords.org/mcc/the-laws/bye-and-leg-bye) | Account for extras | Distinguish primary outcomes from incidental work and overhead in the report. |
| [24 — Absence and substitutes](https://www.lords.org/mcc/the-laws/fielders-absence;-substitutes) | Call a substitute | Identify an available substitute tool or owner; explain any capability gap. |
| [25 — Batter's innings and runners](https://www.lords.org/mcc/the-laws/batsman-s-innings;-runners) | Manage the handoff | Prepare the state and responsibilities needed for another person or session to continue. |
| [26 — Practice](https://www.lords.org/mcc/the-laws/practice-on-the-field) | Nets session | Exercise the requested behavior using appropriate fixtures or a dry run. |
| [27 — The wicket-keeper](https://www.lords.org/mcc/the-laws/the-wicket-keeper) | Keeper ready | Check the input/output boundary for missing, duplicated, or malformed data. |
| [28 — The fielder](https://www.lords.org/mcc/the-laws/the-fielder) | Field it | Review the supplied work for actionable defects and uncovered cases. |
| [29 — The wicket is broken](https://www.lords.org/mcc/the-laws/the-wicket-is-down) | Check the wicket | Verify that a reported failure really meets the system's failure condition. |
| [30 — Batter out of ground](https://www.lords.org/mcc/the-laws/batsman-out-of-his-her-ground) | Ground the bat | Verify that the required result has been saved and can be read back. |
| [31 — Appeals](https://www.lords.org/mcc/the-laws/appeals) | How's that? | Assemble concise evidence for a disputed finding or a required user decision. |
| [32 — Bowled](https://www.lords.org/mcc/the-laws/bowled) | Root-cause wicket | Trace a direct failure to its cause and make the appropriate scoped fix. |
| [33 — Caught](https://www.lords.org/mcc/the-laws/caught) | Catch this | Review a change and produce reproducible, evidence-backed findings. |
| [34 — Hit the ball twice](https://www.lords.org/mcc/the-laws/hit-the-ball-twice) | Check duplicate effects | Inspect retry or idempotency behavior before repeating a side-effecting operation. |
| [35 — Hit wicket](https://www.lords.org/mcc/the-laws/hit-wicket) | Check the regression | Investigate whether the change broke its own dependencies or assumptions. |
| [36 — Leg before wicket](https://www.lords.org/mcc/the-laws/leg-before-wicket) | Trace the obstruction | Trace a blocked path and distinguish actual blockers from incidental conditions. |
| [37 — Obstructing the field](https://www.lords.org/mcc/the-laws/obstructing-the-field) | Clear the field | Identify conflicting operations, resource contention, or incompatible changes. |
| [38 — Run out](https://www.lords.org/mcc/the-laws/run-out) | Check the race | Diagnose a race condition, stale state, or handoff timing failure. |
| [39 — Stumped](https://www.lords.org/mcc/the-laws/stumped) | Check readiness | Find which prerequisite was absent when the operation was attempted. |
| [40 — Timed out](https://www.lords.org/mcc/the-laws/timed-out) | Check the timeout | Inspect timeout evidence and destination state before deciding whether to retry. |
| [41 — Unfair play](https://www.lords.org/mcc/the-laws/unfair-play) | Fair-play review | Review the requested design for specified fairness or integrity requirements. |
| [42 — Players' conduct](https://www.lords.org/mcc/the-laws/players-conduct) | Team conduct | Rewrite a difficult team communication to be clear, respectful, and actionable. |

The [Spirit of Cricket](https://www.lords.org/mcc/the-laws/spirit-of-cricket) is an additional reference for the character's fair-play theme. The political personality belongs to this fictional pet; no stance or endorsement is attributed to MCC or any athlete.
