---
name: cricket-matchday
description: Add sourced cricket match, fixture and player updates to Cricket Kennel conversations, with ESPNcricinfo web lookup or an optional locally configured Sportradar adapter.
---

# Cricket Match Day

Give the chosen dog companion a short, sourced cricket update. This separately installed Codex add-on works without API access through normal source-link lookup. API mode starts disabled. Installing the skill does not buy, configure or enable a data service.

## Choose the requested source

For an ESPNcricinfo URL or a request for ESPNcricinfo, use [source-link mode](references/source-links.md). Open the provided page using an available browser or web tool, read the relevant facts, and link the source with the retrieval time. This is web research, not an ESPN API. Do not call undocumented endpoints, defeat access restrictions or invent statistics when the page is unavailable.

For fixtures, a match summary or a player profile through the user's own configured Sportradar access, read [API mode](references/api-mode.md) and run the read-only adapter. `status` is a local check that makes no network request. Do not create an account, buy access or enable the API merely because the skill was selected. The user supplies their key through their local environment; never ask them to paste it into a conversation.

## Make the update useful

Keep the real cricket result separate from the companion's fictional voice. Label provider/source, retrieved time, provider generation time when supplied, and fresh/cached/stale/unavailable status. A freshly fetched response can still contain old provider data. State any missing coverage. Historical player profiles and detailed ball or shot data are not guaranteed.

Keep every Test innings distinct. Preserve wickets, dismissal types and extras as separate fields. `19.5` means 19 overs and 5 legal balls in six-ball formats; the next legal ball is `20.0`. Never perform decimal arithmetic on overs or count wides/no-balls as legal balls. Keep unfamiliar formats in provider notation.

Use the existing companion's character in the commentary without changing the facts: Brian can offer a tea-break recap, Cornwall's character can celebrate a boundary, and the 12th man can bring the drinks. Verify a real player's identity before attaching statistics; provider IDs are not interchangeable. Do not infer any real person's personality from a pet persona.

This add-on does not control native pet animation frames, connect ChatGPT tasks, monitor conversations, send notifications or alter the separate productivity scorebook. Real match runs never become Codex work credits automatically.

See [README.md](README.md) for optional installation and offline checks. Tests and synthetic fixtures are included; synthetic results must never be presented as real cricket.
