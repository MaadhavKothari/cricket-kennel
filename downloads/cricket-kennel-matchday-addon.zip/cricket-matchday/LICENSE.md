# Cricket Kennel Match Day — CC BY-NC 4.0

The original instructions, adapter source and synthetic test fixtures in this package are offered under the Creative Commons Attribution–NonCommercial 4.0 International licence, to the extent copyright and similar rights apply and the creator can license them.

- Creator: Maadhav Kothari
- Attribution: https://maadhavkothari.github.io/cricket-kennel/#licence
- Licence: https://creativecommons.org/licenses/by-nc/4.0/
- Full terms: https://creativecommons.org/licenses/by-nc/4.0/legalcode.en

Third-party source data, API access, trademarks and linked materials are not licensed by this notice. This package grants no right to redistribute a provider's feed. No ESPNcricinfo, Sportradar, athlete, cricket body or OpenAI endorsement is implied. No music, pet artwork or personal photograph is included.
