#!/usr/bin/env node
import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';

export const PROVIDER = 'Sportradar Cricket v2';
const ORIGIN = 'https://api.sportradar.com';
const MAX_BYTES = 2 * 1024 * 1024;
const MAX_REQUESTS = 4;
const SIX_BALL_FORMATS = new Set(['test', 'odi', 't10', 't20i', 'first_class', 'list_a', 't20']);
const array = value => Array.isArray(value) ? value : [];
const object = value => value && typeof value === 'object' && !Array.isArray(value);
const integer = value => Number.isSafeInteger(value) && value >= 0 ? value : null;
const timestamp = value => typeof value === 'string' && Number.isFinite(Date.parse(value)) ? value : null;
const pick = (value, keys) => Object.fromEntries(keys.filter(key => value?.[key] !== undefined).map(key => [key, value[key]]));
const ttlFor = kind => kind === 'match' ? 60_000 : 300_000;

// Provider numbers such as 33.3 represent 33 overs and 3 balls, never 33.3 overs.
export function parseOvers(value, format) {
  const display = ['string', 'number'].includes(typeof value) ? String(value) : null;
  if (display === null) return null;
  if (!SIX_BALL_FORMATS.has(format)) return {display, notation: 'provider', legal_balls: null};
  const match = /^(0|[1-9]\d*)(?:\.([0-5]))?$/.exec(display);
  if (!match || !Number.isSafeInteger(Number(match[1]) * 6)) return {display, notation: 'unrecognized', legal_balls: null};
  const complete = Number(match[1]);
  const balls = Number(match[2] ?? 0);
  return {display: `${complete}.${balls}`, notation: 'overs.balls', complete_overs: complete, balls_this_over: balls, legal_balls: complete * 6 + balls};
}

function sanitized(value, secret = '', depth = 0) {
  if (depth > 40) return null;
  if (typeof value === 'string') return secret ? value.split(secret).join('[REDACTED]') : value;
  if (Array.isArray(value)) return value.map(item => sanitized(item, secret, depth + 1));
  if (object(value)) return Object.fromEntries(Object.entries(value).filter(([key]) => !/^(api[_-]?key|authorization|token|access_token|secret)$/i.test(key)).map(([key, item]) => [secret ? key.split(secret).join('[REDACTED]') : key, sanitized(item, secret, depth + 1)]));
  return value;
}

export function normalizeMatch(payload) {
  if (!object(payload?.sport_event) || !object(payload?.sport_event_status)) throw new Error('invalid_payload');
  const format = payload.sport_event_conditions?.type ?? payload.sport_event.tournament?.type ?? null;
  const status = payload.sport_event_status;
  const periods = array(status.period_scores).map(period => ({...period, overs: parseOvers(period.display_overs, format)}));
  const innings = array(payload.statistics?.innings).map(inning => {
    const teams = array(inning.teams);
    const batting = teams.find(team => team.id === inning.batting_team)?.statistics?.batting;
    const bowling = teams.find(team => team.id === inning.bowling_team)?.statistics?.bowling;
    return {
      number: integer(inning.number), batting_team: inning.batting_team ?? null, bowling_team: inning.bowling_team ?? null,
      runs: integer(batting?.runs), wickets: integer(batting?.wickets_lost),
      overs: parseOvers(periods.find(period => period.number === inning.number)?.display_overs, format),
      extras: {
        byes: integer(bowling?.byes), leg_byes: integer(bowling?.leg_byes), wides: integer(bowling?.wides),
        no_balls: integer(bowling?.no_balls), penalty_runs: integer(batting?.penalty_runs),
        provider_bowling_extras: integer(bowling?.bowling_extras),
      },
      dismissals: array(batting?.players).filter(player => object(player.statistics?.dismissal)).map(player => ({
        player_id: player.id ?? null, player_name: player.name ?? null, ...player.statistics.dismissal,
      })),
      provider_statistics: inning,
    };
  });
  return {
    match: payload.sport_event, format, status: status.status ?? null, match_status: status.match_status ?? null,
    result: status.match_result_text ?? null, current_inning: integer(status.current_inning),
    current_score: status.display_score ?? null, current_overs: parseOvers(status.display_overs, format),
    period_scores: periods, innings, coverage: payload.coverage ?? null,
    coverage_note: 'Only supplied fields are shown. Missing statistics are unknown, not zero; coverage and historical availability depend on the provider entitlement.',
  };
}

function normalize(kind, payload) {
  if (!object(payload)) throw new Error('invalid_payload');
  if (kind === 'match') return normalizeMatch(payload);
  if (kind === 'fixtures') {
    if (!Array.isArray(payload.sport_events)) throw new Error('invalid_payload');
    return {fixtures: payload.sport_events, coverage_note: 'Provider-listed fixtures only; an empty list does not prove no cricket is being played.'};
  }
  if (!object(payload.player)) throw new Error('invalid_payload');
  return {...pick(payload, ['player', 'teams', 'roles']), coverage_note: 'Only returned profile fields are available. Lifetime, historical and format statistics are not guaranteed.'};
}

export function endpoint(kind, target, access = 't') {
  if (!['t', 'p'].includes(access)) throw new Error('invalid_configuration');
  let suffix;
  if (kind === 'fixtures') {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(target ?? '') || !Number.isFinite(Date.parse(target + 'T00:00:00Z')) || new Date(target + 'T00:00:00Z').toISOString().slice(0, 10) !== target) throw new Error('invalid_target');
    suffix = `schedules/${target}/schedule.json`;
  } else if (kind === 'match') {
    // Both forms appear in official v2 documentation. Copy the ID from this provider's response.
    if (!/^sr:(?:sport_event|match):\d+$/.test(target ?? '')) throw new Error('invalid_target');
    suffix = `matches/${target}/summary.json`;
  } else if (kind === 'player') {
    if (!/^sr:player:\d+$/.test(target ?? '')) throw new Error('invalid_target');
    suffix = `players/${target}/profile.json`;
  } else throw new Error('invalid_operation');
  return `${ORIGIN}/cricket-${access}2/en/${suffix}`;
}

const messages = {
  disabled: 'API mode is disabled. Use source-link mode or explicitly activate your own provider access.',
  missing_key: 'API mode is enabled but SPORTRADAR_API_KEY is missing.',
  invalid_configuration: 'Use access level t or p and a valid environment API key.',
  invalid_target: 'Use a valid date or an ID copied from the selected Sportradar feed; ESPN IDs and arbitrary URLs are not accepted.',
  invalid_operation: 'Use status, fixtures, match or player.',
  unauthorized: 'The provider rejected authentication. The key may be invalid or expired.',
  forbidden: 'The provider denied access. Check the key entitlement and selected access level.',
  rate_limited: 'The provider rate limit was reached. No automatic retry was made.',
  not_found: 'The requested provider resource is unavailable or not covered.',
  redirect_blocked: 'The provider redirected the request. Redirects are blocked to protect the API key.',
  invalid_payload: 'The provider response was not a supported JSON payload.',
  response_too_large: 'The provider response exceeded the 2 MiB limit.',
  network_error: 'The provider request failed or timed out. No automatic retry was made.',
  provider_error: 'The provider returned an unsuccessful response.',
  request_budget: 'The invocation limit of four requests was reached. No further request was made.',
};

async function readJSON(response) {
  if (Number(response.headers.get('content-length')) > MAX_BYTES) throw new Error('response_too_large');
  const reader = response.body?.getReader();
  if (!reader) throw new Error('invalid_payload');
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const {done, value} = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_BYTES) throw new Error('response_too_large');
      chunks.push(Buffer.from(value));
    }
    try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw new Error('invalid_payload'); }
  } finally { await reader.cancel().catch(() => {}); }
}

// Cache exists only in this object, never on disk. No timers or background polling.
export function createMatchday({env = process.env, fetchImpl = globalThis.fetch, now = Date.now} = {}) {
  const enabled = env.MATCHDAY_API_ENABLED === '1';
  const key = env.SPORTRADAR_API_KEY ?? '';
  const access = env.SPORTRADAR_ACCESS_LEVEL ?? 't';
  const validConfiguration = ['t', 'p'].includes(access) && typeof key === 'string' && !/[\r\n]/.test(key) && key.length <= 256;
  const cache = new Map();
  let requestCount = 0;
  const status = () => ({
    schema_version: 1, mode: enabled ? 'api' : 'source_links', provider: PROVIDER, api_enabled: enabled,
    key_present: Boolean(key), access_level: ['t', 'p'].includes(access) ? access : null,
    readiness: !enabled ? 'disabled' : !key ? 'missing_key' : validConfiguration ? 'configured_unverified' : 'invalid_configuration',
    live_access_verified: false, requests_this_invocation: requestCount, request_limit: MAX_REQUESTS,
    cache: 'memory_only', checked_at: new Date(now()).toISOString(),
  });
  async function get(kind, target) {
    if (kind === 'status') return status();
    const checkedAt = new Date(now()).toISOString();
    let sourceUrl = null;
    const fail = (code, prior = null, retryAfter = null) => {
      const canServeStale = prior && ['network_error', 'provider_error', 'rate_limited', 'request_budget'].includes(code) && now() - prior.cachedAt <= 3_600_000;
      return {
        schema_version: 1, provider: PROVIDER, operation: kind, status: canServeStale ? 'stale' : code === 'disabled' ? 'disabled' : 'unavailable',
        source_url: sourceUrl, checked_at: checkedAt, retrieved_at: canServeStale ? prior.result.retrieved_at : null,
        provider_generated_at: canServeStale ? prior.result.provider_generated_at : null,
        error: {code, message: messages[code], ...(retryAfter === null ? {} : {retry_after_seconds: retryAfter})},
        data: canServeStale ? structuredClone(prior.result.data) : null,
      };
    };
    if (!enabled) return fail('disabled');
    if (!key) return fail('missing_key');
    if (!validConfiguration) return fail('invalid_configuration');
    try { sourceUrl = endpoint(kind, target, access); } catch (error) { return fail(error.message); }
    const prior = cache.get(sourceUrl);
    if (prior && now() - prior.cachedAt < ttlFor(kind)) return {...structuredClone(prior.result), status: 'cached', checked_at: checkedAt};
    if (requestCount >= MAX_REQUESTS) return fail('request_budget', prior);
    requestCount++;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetchImpl(sourceUrl, {method: 'GET', redirect: 'manual', headers: {accept: 'application/json', 'x-api-key': key}, signal: controller.signal});
      // Never inspect an error body or expose raw fetch exceptions: either can contain a key.
      if (response.redirected || (response.status >= 300 && response.status < 400)) { await response.body?.cancel(); return fail('redirect_blocked'); }
      if (!response.ok) {
        const code = ({401: 'unauthorized', 403: 'forbidden', 404: 'not_found', 429: 'rate_limited'})[response.status] ?? 'provider_error';
        const retry = response.headers.get('retry-after');
        await response.body?.cancel();
        return fail(code, prior, code === 'rate_limited' && /^\d{1,6}$/.test(retry ?? '') ? Number(retry) : null);
      }
      const payload = sanitized(await readJSON(response), key);
      const result = {
        schema_version: 1, provider: PROVIDER, operation: kind, status: 'fresh', source_url: sourceUrl,
        checked_at: checkedAt, retrieved_at: new Date(now()).toISOString(), provider_generated_at: timestamp(payload.generated_at),
        data: normalize(kind, payload),
      };
      if (cache.size >= 16) cache.delete(cache.keys().next().value);
      cache.set(sourceUrl, {cachedAt: now(), result});
      return structuredClone(result);
    } catch (error) {
      const code = ['invalid_payload', 'response_too_large'].includes(error?.message) ? error.message : 'network_error';
      return fail(code, prior);
    } finally { clearTimeout(timer); }
  }
  return {status, get};
}

export async function main(args = process.argv.slice(2), options = {}) {
  if (!args.length || args.length > 2 || !['status', 'fixtures', 'match', 'player'].includes(args[0]) || (args[0] === 'status' ? args.length !== 1 : args.length !== 2)) {
    return {status: 'unavailable', error: {code: 'usage', message: 'Use: node scripts/matchday.mjs status | fixtures YYYY-MM-DD | match PROVIDER_ID | player PROVIDER_ID'}};
  }
  return createMatchday(options).get(args[0], args[1]);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === await fs.realpath(process.argv[1]).catch(() => null)) {
  const result = await main();
  console.log(JSON.stringify(result, null, 2));
  if (result.status === 'unavailable') process.exitCode = 1;
}
