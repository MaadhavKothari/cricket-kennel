import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createMatchday, endpoint, normalizeMatch, parseOvers, main} from './matchday.mjs';

const fixture = JSON.parse(await fs.readFile(new URL('../fixtures/synthetic-test-match.json', import.meta.url), 'utf8'));
const secret = 'synthetic-test-key-never-live';
const env = {MATCHDAY_API_ENABLED: '1', SPORTRADAR_API_KEY: secret};
const matchId = fixture.sport_event.id;
const jsonResponse = (body, status = 200, headers = {}) => new Response(JSON.stringify(body), {status, headers: {'content-type': 'application/json', ...headers}});
const unreachable = () => { throw new Error('Unexpected HTTP request'); };

test('disabled API and status perform zero HTTP calls, including configured status', async () => {
  let calls = 0;
  const fetchImpl = async () => { calls++; throw new Error('unexpected'); };
  const disabled = createMatchday({env: {}, fetchImpl});
  assert.equal((await disabled.get('match', matchId)).status, 'disabled');
  assert.equal((await disabled.get('status')).readiness, 'disabled');
  const configured = createMatchday({env, fetchImpl});
  assert.equal(configured.status().readiness, 'configured_unverified');
  assert.equal(configured.status().live_access_verified, false);
  assert.equal(calls, 0);
  assert.ok(!JSON.stringify(configured.status()).includes(secret));
});

test('missing key and invalid configuration fail locally without HTTP', async () => {
  assert.equal((await createMatchday({env: {MATCHDAY_API_ENABLED: '1'}, fetchImpl: unreachable}).get('match', matchId)).error.code, 'missing_key');
  assert.equal((await createMatchday({env: {...env, SPORTRADAR_ACCESS_LEVEL: 'elsewhere'}, fetchImpl: unreachable}).get('match', matchId)).error.code, 'invalid_configuration');
  assert.equal((await createMatchday({env: {...env, SPORTRADAR_API_KEY: 'bad\nheader'}, fetchImpl: unreachable}).get('match', matchId)).error.code, 'invalid_configuration');
});

test('only exact documented endpoints accept provider IDs and real calendar dates', () => {
  assert.equal(endpoint('fixtures', '2026-09-19'), 'https://api.sportradar.com/cricket-t2/en/schedules/2026-09-19/schedule.json');
  assert.equal(endpoint('match', 'sr:sport_event:123', 'p'), 'https://api.sportradar.com/cricket-p2/en/matches/sr:sport_event:123/summary.json');
  assert.ok(endpoint('match', 'sr:match:123').endsWith('/matches/sr:match:123/summary.json'));
  assert.ok(endpoint('player', 'sr:player:123').endsWith('/players/sr:player:123/profile.json'));
  for (const target of ['494581', 'https://evil.example/key', 'sr:player:123/../../x', 'sr:player:123?api_key=x']) assert.throws(() => endpoint('player', target));
  for (const target of ['2026-02-30', '2026-13-01', 'tomorrow', '../schedule']) assert.throws(() => endpoint('fixtures', target));
});

test('request is one fixed-host GET with header credential and manual redirects', async () => {
  let calls = 0;
  const adapter = createMatchday({env, fetchImpl: async (url, options) => {
    calls++;
    assert.equal(new URL(url).origin, 'https://api.sportradar.com');
    assert.ok(!url.includes(secret));
    assert.equal(options.method, 'GET');
    assert.equal(options.redirect, 'manual');
    assert.equal(options.headers['x-api-key'], secret);
    assert.ok(options.signal instanceof AbortSignal);
    return jsonResponse(fixture);
  }});
  const result = await adapter.get('match', matchId);
  assert.equal(result.status, 'fresh');
  assert.equal(calls, 1);
  assert.equal(result.provider_generated_at, fixture.generated_at);
});

test('four Test innings retain order, wickets, extras and LBW dismissal', () => {
  const data = normalizeMatch(fixture);
  assert.deepEqual(data.innings.map(i => [i.number, i.runs, i.wickets]), [[1,300,10],[2,280,10],[3,120,2],[4,32,1]]);
  assert.equal(data.period_scores.length, 4);
  assert.equal(data.innings[0].extras.no_balls, 1);
  assert.equal(data.innings[0].extras.provider_bowling_extras, 4);
  assert.equal(data.innings[0].dismissals[0].type, 'leg_before_wicket');
  assert.equal(data.innings[0].provider_statistics.batting_team, fixture.statistics.innings[0].batting_team);
  assert.equal(data.current_overs.legal_balls, 53);
});

test('overs use integer balls and preserve unsupported or malformed notation', () => {
  assert.equal(parseOvers(19.5, 'test').legal_balls, 119);
  assert.equal(parseOvers('20.0', 'odi').legal_balls, 120);
  assert.equal(parseOvers(0, 't20').legal_balls, 0);
  assert.equal(parseOvers('19.6', 'test').legal_balls, null);
  assert.equal(parseOvers('19.25', 'test').notation, 'unrecognized');
  assert.deepEqual(parseOvers('19.5', 'the_hundred'), {display: '19.5', notation: 'provider', legal_balls: null});
  assert.equal(parseOvers(null, 'test'), null);
});

test('missing details remain unknown and period scores survive without innings stats', () => {
  const sparse = structuredClone(fixture);
  delete sparse.statistics;
  assert.equal(normalizeMatch(sparse).innings.length, 0);
  assert.equal(normalizeMatch(sparse).period_scores.length, 4);
  sparse.statistics = {innings: [{number: 1, teams: []}]};
  const inning = normalizeMatch(sparse).innings[0];
  assert.equal(inning.runs, null);
  assert.equal(inning.extras.no_balls, null);
  assert.deepEqual(inning.dismissals, []);
});

test('retired hurt is preserved without changing provider wicket count', () => {
  const sample = structuredClone(fixture);
  sample.statistics.innings[0].teams[0].statistics.batting.players[0].statistics.dismissal.type = 'retired_hurt';
  const inning = normalizeMatch(sample).innings[0];
  assert.equal(inning.dismissals[0].type, 'retired_hurt');
  assert.equal(inning.wickets, 10);
});

test('authentication, forbidden and rate-limit errors are clear and never leak response bodies', async () => {
  for (const [status, code] of [[401,'unauthorized'],[403,'forbidden'],[404,'not_found'],[429,'rate_limited'],[500,'provider_error']]) {
    let calls = 0;
    const adapter = createMatchday({env, fetchImpl: async () => { calls++; return jsonResponse({error: secret}, status, {'retry-after': '30'}); }});
    const result = await adapter.get('match', matchId);
    assert.equal(result.error.code, code);
    assert.equal(result.data, null);
    assert.ok(!JSON.stringify(result).includes(secret));
    assert.equal(calls, 1);
    if (status === 429) assert.equal(result.error.retry_after_seconds, 30);
  }
});

test('redirect targets are not followed or exposed', async () => {
  let calls = 0;
  const adapter = createMatchday({env, fetchImpl: async () => { calls++; return new Response(secret, {status: 302, headers: {location: 'https://evil.example/' + secret}}); }});
  const result = await adapter.get('player', 'sr:player:1');
  assert.equal(result.error.code, 'redirect_blocked');
  assert.equal(calls, 1);
  assert.ok(!JSON.stringify(result).includes(secret));
  assert.ok(!JSON.stringify(result).includes('evil.example'));
});

test('raw network errors and a credential echoed in successful data are redacted', async () => {
  const errorResult = await createMatchday({env, fetchImpl: async () => { throw new Error(secret); }}).get('match', matchId);
  assert.equal(errorResult.error.code, 'network_error');
  assert.ok(!JSON.stringify(errorResult).includes(secret));
  const dataResult = await createMatchday({env, fetchImpl: async () => jsonResponse({player: {id: 'sr:player:1', name: secret, api_key: secret, [secret]: 'echoed key'}})}).get('player', 'sr:player:1');
  assert.equal(dataResult.data.player.name, '[REDACTED]');
  assert.ok(!('api_key' in dataResult.data.player));
  assert.ok(!JSON.stringify(dataResult).includes(secret));
});

test('memory cache avoids requests, keeps retrieval time and cannot be mutated by its caller', async () => {
  let time = Date.parse('2026-01-01T12:00:00Z');
  let calls = 0;
  const adapter = createMatchday({env, now: () => time, fetchImpl: async () => { calls++; return jsonResponse(fixture); }});
  const first = await adapter.get('match', matchId);
  first.data.innings[0].runs = -1;
  time += 20_000;
  const cached = await adapter.get('match', matchId);
  assert.equal(cached.status, 'cached');
  assert.equal(cached.data.innings[0].runs, 300);
  assert.equal(cached.retrieved_at, first.retrieved_at);
  assert.notEqual(cached.checked_at, first.checked_at);
  assert.equal(calls, 1);
});

test('transient failure labels bounded stale data; authentication never returns stale data', async () => {
  let time = Date.parse('2026-01-01T12:00:00Z');
  let responseStatus = 200;
  const adapter = createMatchday({env, now: () => time, fetchImpl: async () => jsonResponse(fixture, responseStatus)});
  const first = await adapter.get('match', matchId);
  time += 61_000;
  responseStatus = 503;
  const stale = await adapter.get('match', matchId);
  assert.equal(stale.status, 'stale');
  assert.equal(stale.retrieved_at, first.retrieved_at);
  responseStatus = 401;
  assert.equal((await adapter.get('match', matchId)).data, null);
  time += 3_600_000;
  responseStatus = 503;
  assert.equal((await adapter.get('match', matchId)).status, 'unavailable');
});

test('adapter request budget is bounded and never automatically retries', async () => {
  let calls = 0;
  const adapter = createMatchday({env, fetchImpl: async () => { calls++; return jsonResponse({error: secret}, 500); }});
  for (let i = 0; i < 4; i++) assert.equal((await adapter.get('match', matchId)).error.code, 'provider_error');
  assert.equal((await adapter.get('match', matchId)).error.code, 'request_budget');
  assert.equal(calls, 4);
});

test('malformed and oversized responses fail safely', async () => {
  const malformed = createMatchday({env, fetchImpl: async () => new Response('not-json ' + secret)});
  assert.equal((await malformed.get('match', matchId)).error.code, 'invalid_payload');
  const unsupported = createMatchday({env, fetchImpl: async () => jsonResponse({unexpected: true})});
  assert.equal((await unsupported.get('match', matchId)).error.code, 'invalid_payload');
  const oversized = createMatchday({env, fetchImpl: async () => new Response('x'.repeat(2 * 1024 * 1024 + 1))});
  assert.equal((await oversized.get('match', matchId)).error.code, 'response_too_large');
});

test('fixture and player endpoints preserve provider data without inventing stats', async () => {
  const adapter = createMatchday({env, fetchImpl: async url => url.includes('/schedules/') ? jsonResponse({generated_at: fixture.generated_at, sport_events: [fixture.sport_event]}) : jsonResponse({player: {id: 'sr:player:1', name: 'Synthetic Player'}, teams: [], roles: []})});
  assert.equal((await adapter.get('fixtures', '2026-09-19')).data.fixtures[0].id, matchId);
  const profile = await adapter.get('player', 'sr:player:1');
  assert.equal(profile.data.player.name, 'Synthetic Player');
  assert.ok(!('statistics' in profile.data.player));
});

test('invalid CLI arguments and targets are never echoed or requested', async () => {
  const result = await main(['match', secret, 'extra'], {env, fetchImpl: unreachable});
  assert.equal(result.error.code, 'usage');
  assert.ok(!JSON.stringify(result).includes(secret));
  assert.equal((await main(['player', '494581'], {env, fetchImpl: unreachable})).error.code, 'invalid_target');
});

test('CLI works through a symlink and does not create or change score or cache files', async () => {
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'matchday-readonly-'));
  try {
    const sentinel = path.join(temp, 'scorebook.json');
    await fs.writeFile(sentinel, '{"runs":99}\n');
    const script = path.join(temp, 'matchday-link.mjs');
    await fs.symlink(fileURLToPath(new URL('./matchday.mjs', import.meta.url)), script);
    const before = await fs.readdir(temp);
    const output = execFileSync(process.execPath, [script, 'status'], {cwd: temp, env: {PATH: process.env.PATH, MATCHDAY_API_ENABLED: '0'}, encoding: 'utf8'});
    assert.equal(JSON.parse(output).readiness, 'disabled');
    assert.equal(await fs.readFile(sentinel, 'utf8'), '{"runs":99}\n');
    assert.deepEqual(await fs.readdir(temp), before);
  } finally { await fs.rm(temp, {recursive: true, force: true}); }
});
