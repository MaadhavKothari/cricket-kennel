# Optional Sportradar API mode

Read-only adapter for the documented Cricket v2 API. Exact endpoint templates and JSON fields were checked against the primary documentation on **19 September 2026**. No credentialed live call or account entitlement has been verified.

## Activate locally

You need your own key with Cricket entitlement. Set `SPORTRADAR_API_KEY` in the local environment through your normal secret manager; do not put the value in chat, source files, a ZIP or shell-history examples. Then explicitly set:

```sh
export MATCHDAY_API_ENABLED=1
export SPORTRADAR_ACCESS_LEVEL=t
node scripts/matchday.mjs status
```

`t` selects trial access; `p` selects production. Select the level associated with your existing access. These variables do not purchase or grant an entitlement. `configured_unverified` means only that the local variables are present. Status does not contact the provider or validate the key. Unset `MATCHDAY_API_ENABLED` to disable API mode.

The adapter uses the `x-api-key` header described in the current [authentication guidance](https://developer.sportradar.com/getting-started/docs/authentication). The key never appears in the request URL. Only the fixed `api.sportradar.com` host and the endpoint shapes below are supported. Redirects are blocked, errors are redacted, and response content is treated as untrusted data.

## Commands and identity

```sh
node scripts/matchday.mjs fixtures 2026-09-19
node scripts/matchday.mjs match 'PROVIDER_MATCH_ID'
node scripts/matchday.mjs player 'PROVIDER_PLAYER_ID'
```

The last two values are placeholders: replace them with IDs **copied from a Sportradar response**, never a number from ESPNcricinfo. A daily schedule supplies match IDs; match player statistics supply player IDs when covered. Confirm identity against the returned name and teams. There is no automatic cross-provider matching or player-name search in this adapter.

| Operation | Documented path after `https://api.sportradar.com` |
| --- | --- |
| Fixtures | `/cricket-{t\|p}2/en/schedules/{YYYY-MM-DD}/schedule.json` |
| Match | `/cricket-{t\|p}2/en/matches/{provider_match_id}/summary.json` |
| Player | `/cricket-{t\|p}2/en/players/{sr:player:ID}/profile.json` |

The OpenAPI specification uses `sr:sport_event:ID` for match IDs; the current Match Summary reference also shows `sr:match:ID`. The adapter accepts both documented namespaces, without translating between them. Feed-supplied IDs are authoritative. It rejects arbitrary URLs, plain numeric ESPN IDs and path traversal.

## Output and limits

Each command prints JSON with provider, source URL, retrieval and check timestamps, provider generation timestamp when supplied, and a freshness status. Fresh means a new HTTP response, not a guarantee that the upstream data is current. A profile, fixture or score can be delayed or absent because of coverage or entitlement. The adapter preserves unknown fields in match innings under `provider_statistics`; missing score fields become `null`, never invented zeros.

All Test innings remain separate. Period scores are preserved even when detailed innings statistics are absent. Runs, wickets, extras and player dismissal records are structured separately. A dismissal such as `retired_hurt` is preserved without assuming it counts as a wicket. No total extras is invented from an incomplete breakdown. In supported six-ball formats, overs are converted using integer balls (`19.5` = 119 balls); other formats keep the provider notation without conversion.

There are no retries or background tasks. A CLI command makes at most one GET request, bounded to eight seconds and 2 MiB. Programmatic callers using `createMatchday()` share a memory-only cache (60 seconds for matches; 300 seconds for fixtures/profiles), at most 16 entries and four requests per adapter instance. Each invocation should create at most one instance. Cache disappears when the process ends. A transient failure may return data up to one hour old marked `stale`, retaining its original retrieval time. Authentication, forbidden and missing-key failures never serve cached data. HTTP 429 includes numeric Retry-After when supplied; the next request needs a new user invocation after the wait, not a polling loop.

The CLI writes only JSON to stdout. It never reads or writes the Cricket Kennel scorebook, skills configuration, pet assets or cache files. Do not route real match runs into the separate Codex task score.

## Primary references

- [Cricket overview and coverage](https://developer.sportradar.com/cricket/reference/cricket-overview)
- [Daily Schedule](https://developer.sportradar.com/cricket/reference/cricket-daily-schedule)
- [Match Summary](https://developer.sportradar.com/cricket/reference/cricket-match-summary)
- [Player Profile](https://developer.sportradar.com/cricket/reference/cricket-player-profile)
- [Official OpenAPI specification](https://schemas.sportradar.com/sportsapi/cricket/v2/openapi/openapi.yaml)
- [Authentication and headers](https://developer.sportradar.com/getting-started/docs/authentication)

Provider product access, billing and permitted use remain governed by your own provider account and terms. No paid service is included in this download.
