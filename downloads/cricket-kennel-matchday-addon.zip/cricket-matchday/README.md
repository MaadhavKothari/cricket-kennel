# Cricket Kennel — Match Day add-on

An optional, separately installed **Codex skill** for cricket updates in your companion's voice. ESPNcricinfo works as sourced web lookup using your available browsing tool. A small Sportradar adapter supports your own provider access. No supported self-service ESPNcricinfo API was verified for this release.

## Install

Unzip `cricket-kennel-matchday-addon.zip`. Copy its `cricket-matchday` folder into `$CODEX_HOME/skills` (normally `~/.codex/skills`), then restart Codex. If that folder already exists, keep your existing version safe before replacing it. No other Cricket Kennel package is required. Automatic skill discovery retains the Codex default; API activation is separate.

Try: “Use $cricket-matchday with Brian to look up this ESPNcricinfo match and give me a tea-break recap.” See [source-link mode](references/source-links.md).

## Local checks

From the extracted `cricket-matchday` directory, with Node.js 20 or newer:

```sh
node scripts/matchday.mjs status
node --test scripts/matchday.test.mjs
```

The status command and tests make **zero live HTTP requests**. The default API state is disabled. Tests use injected responses and a clearly synthetic four-innings match.

For API use, see [configuration and commands](references/api-mode.md). You need your own entitled Sportradar key and must explicitly activate API mode. No account, subscription, credential, configuration or live entitlement was created or verified for this release. The adapter has been tested against fixtures derived from the documented schema, not a credentialed live account.

The adapter performs at most one request per command, with an eight-second timeout and a 2 MiB response limit. It has no background polling, on-disk cache, score writes, alerts or native animation control. Source data remains subject to its provider's terms; this package grants no feed redistribution rights.

To remove the add-on, delete only the installed `cricket-matchday` folder and remove any Match Day variables you set from your own environment. Pet downloads and the separate task scorekeeper continue to work.
