Jack Hounds
Cricket Kennel

An original fictional dog inspired by Jack Hobbs. No athlete endorsement is implied. AI-assisted artwork with human art direction.

DESKTOP / CODEX CLI
Unzip this archive. Copy the jack-hounds-test folder into your .codex/pets directory in your home folder (create it if needed). Keep pet.json and spritesheet.webp together. If a folder with this name already exists, back it up before replacing it. In the desktop app, open Settings > Pets, Refresh and choose Jack Hounds. In an interactive Codex terminal, type /pets and choose this pet. A compatible image-capable terminal is required.

This is a desktop/CLI v2 package with nine activity rows and sixteen look directions. Its extended sheet is not the 1536 x 1872 upload format used by ChatGPT web.

The website's in-browser preview uses these exact pixels. Named cricket illustrations are separate artwork; a chat instruction does not directly trigger a particular native animation.

Website: https://maadhavkothari.github.io/cricket-kennel/
Artwork licence: CC BY-NC 4.0 — https://creativecommons.org/licenses/by-nc/4.0/
Creator attribution: https://maadhavkothari.github.io/cricket-kennel/#licence
Official pet guide: https://learn.chatgpt.com/docs/pets
Sprite SHA-256: e80b7eedf049ab7f0172969911d0cf0c58a89e896a1ac9ce764e329d4f57e9bd
