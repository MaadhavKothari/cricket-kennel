Viv Fetchards
Cricket Kennel — AI companions for ChatGPT and Codex

An original fictional dog inspired by Viv Richards. No athlete endorsement is implied. AI-assisted artwork with human art direction.

CHATGPT DESKTOP / CODEX CLI
Unzip this archive. Copy the viv-fetchards-test folder into your .codex/pets directory in your home folder (create it if needed). Keep pet.json and spritesheet.webp together. If a folder with this name already exists, back it up before replacing it. In the ChatGPT desktop app, open Settings > Pets, Refresh and choose Viv Fetchards. In an interactive Codex terminal, type /pets and choose this pet. A compatible image-capable terminal is required.

This is a desktop/CLI v2 package with nine activity rows and sixteen look directions. Its extended sheet is not the 1536 x 1872 upload format used by ChatGPT web. Pet availability depends on the interface and workspace.

The website's interactive demo uses these exact pixels. Your installed pet follows activity in supported interfaces; the browser demo is not connected to your chats. Choosing a pet customizes its appearance, not the assistant's task behavior. Named cricket illustrations are separate artwork.

Website: https://maadhavkothari.github.io/cricket-kennel/
Artwork licence: CC BY-NC 4.0 — https://creativecommons.org/licenses/by-nc/4.0/
Creator attribution: https://maadhavkothari.github.io/cricket-kennel/#licence
Official pet guide: https://learn.chatgpt.com/docs/pets
Sprite SHA-256: ea800d42982774b807e09d9f0bb702e9c6572ce78da93f643d89e284302ea0b4
