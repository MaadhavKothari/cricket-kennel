Dwayne Brav-woof
Cricket Kennel

An original fictional dog inspired by Dwayne Bravo. No athlete endorsement is implied. AI-assisted artwork with human art direction.

DESKTOP / CODEX CLI
Unzip this archive. Copy the dwayne-brav-woof-test folder into your .codex/pets directory in your home folder (create it if needed). Keep pet.json and spritesheet.webp together. If a folder with this name already exists, back it up before replacing it. In the desktop app, open Settings > Pets, Refresh and choose Dwayne Brav-woof. In an interactive Codex terminal, type /pets and choose this pet. A compatible image-capable terminal is required.

This is a desktop/CLI v2 package with nine activity rows and sixteen look directions. Its extended sheet is not the 1536 x 1872 upload format used by ChatGPT web.

The website's in-browser preview uses these exact pixels. Named cricket illustrations are separate artwork; a chat instruction does not directly trigger a particular native animation.

Website: https://maadhavkothari.github.io/cricket-kennel/
Artwork licence: CC BY-NC 4.0 — https://creativecommons.org/licenses/by-nc/4.0/
Creator attribution: https://maadhavkothari.github.io/cricket-kennel/#licence
Official pet guide: https://learn.chatgpt.com/docs/pets
Sprite SHA-256: b97be71337175c37260af5b2c20221fc4578cfb2d450f45d5038d6ac7b10d75c
